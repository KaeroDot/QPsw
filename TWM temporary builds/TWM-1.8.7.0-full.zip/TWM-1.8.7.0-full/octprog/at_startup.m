% place here command sequence to be executed after GNU Octave/Matlab startup:
%available_graphics_toolkits
%graphics_toolkit('gnuplot');
graphics_toolkit('gnuplot');