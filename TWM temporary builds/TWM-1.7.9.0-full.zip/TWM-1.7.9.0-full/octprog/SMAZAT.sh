#!/bin/bash
cp -f utils/qwtb_restore_twm_input_dims.m qwtb/alg_TWM-Flicker/qwtb_restore_twm_input_dims.m
cp -f utils/qwtb_restore_twm_input_dims.m qwtb/alg_TWM-FPNLSF/qwtb_restore_twm_input_dims.m
cp -f utils/qwtb_restore_twm_input_dims.m qwtb/alg_TWM-HCRMS/qwtb_restore_twm_input_dims.m
cp -f utils/qwtb_restore_twm_input_dims.m qwtb/alg_TWM-InDiSwell/qwtb_restore_twm_input_dims.m
cp -f utils/qwtb_restore_twm_input_dims.m qwtb/alg_TWM-InpZ/qwtb_restore_twm_input_dims.m
cp -f utils/qwtb_restore_twm_input_dims.m qwtb/alg_TWM-LowZ/qwtb_restore_twm_input_dims.m
cp -f utils/qwtb_restore_twm_input_dims.m qwtb/alg_TWM-MFSF/qwtb_restore_twm_input_dims.m
cp -f utils/qwtb_restore_twm_input_dims.m qwtb/alg_TWM-MODTDPS/qwtb_restore_twm_input_dims.m
cp -f utils/qwtb_restore_twm_input_dims.m qwtb/alg_TWM-PSFE/qwtb_restore_twm_input_dims.m
cp -f utils/qwtb_restore_twm_input_dims.m qwtb/alg_TWM-PWRFFT/qwtb_restore_twm_input_dims.m
cp -f utils/qwtb_restore_twm_input_dims.m qwtb/alg_TWM-PWRTDI/qwtb_restore_twm_input_dims.m
cp -f utils/qwtb_restore_twm_input_dims.m qwtb/alg_TWM-PWRTEST/qwtb_restore_twm_input_dims.m
cp -f utils/qwtb_restore_twm_input_dims.m qwtb/alg_TWM-RATWFFT/qwtb_restore_twm_input_dims.m
cp -f utils/qwtb_restore_twm_input_dims.m qwtb/alg_TWM-TEST/qwtb_restore_twm_input_dims.m
cp -f utils/qwtb_restore_twm_input_dims.m qwtb/alg_TWM-THDWFFT/qwtb_restore_twm_input_dims.m
cp -f utils/qwtb_restore_twm_input_dims.m qwtb/alg_TWM-VALID/qwtb_restore_twm_input_dims.m
cp -f utils/qwtb_restore_twm_input_dims.m qwtb/alg_TWM-WFFT/qwtb_restore_twm_input_dims.m
cp -f utils/qwtb_restore_twm_input_dims.m qwtb/alg_TWM-WRMS/qwtb_restore_twm_input_dims.m

