Example of 5922 correction using automatic selection of correction sets
for diffent sampling rates.